#define _ARMA_
class CfgPatches
{
	class airstrike
	{
		units[] = {};
		weapons[] = {};
		AB_Version = 1.0;
		requiredVersion = 1.82;
		requiredAddons[] = {};
		author[]= {"MGTDB"}; 
	};
};
class CfgFunctions
{
	class airstrike
	{
		class main
		{
			file = "airstrike";
			class airstrikeinit
			{
				postInit = 1;
			};
		};
	};
};