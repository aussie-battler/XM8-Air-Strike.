class CfgXM8 
{
	class airstrike
	{
		controlID = 999;
		appID = "App05";
		title = "Air Strike";
	};
};
class XM8_App05_Button: RscExileXM8AppButton1x1
{
    textureNoShortcut = "addons\texture\flag\airstrike.paa";
    text = "Air Strike";
    onButtonClick = "execVM 'Custom\AirStrike\AirStrike.sqf';";
    resource = "";
};